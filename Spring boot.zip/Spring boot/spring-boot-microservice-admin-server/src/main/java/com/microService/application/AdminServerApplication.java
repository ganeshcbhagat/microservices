package com.microService.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import de.codecentric.boot.admin.config.EnableAdminServer;

@SpringBootApplication
@ComponentScan(basePackages = "com.microService")
@EnableAdminServer
public class AdminServerApplication {

	// Run on browser as 
	// http://localhost:8761/
	
	public static void main(String[] args) {
		SpringApplication.run(AdminServerApplication.class, args);
	}
	
}

package com.microService.bean;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;

public class CurrencyConversionBean {

	@ApiModelProperty(notes="Unique ID", required=true)
	private Long id;
	@ApiModelProperty(notes="From currency", required=true)
	private String from;
	@ApiModelProperty(notes="To currency", required=true)
	private String to;
	@ApiModelProperty(notes="Conversion multipler")
	private BigDecimal conversionMultiple;
	@ApiModelProperty(notes="Quantity to convert")
	private BigDecimal quantity;
	@ApiModelProperty(notes="total calcualted amount after conversion")
	private BigDecimal totalCalculatedAmount;
	@ApiModelProperty(notes="Port on which the microservice is running")
	private int port;

	public CurrencyConversionBean() {

	}
	
	public CurrencyConversionBean(Long id, String from, String to, BigDecimal conversionMultiple, BigDecimal quantity,
			BigDecimal totalCalculatedAmount, int port) {
		super();
		this.id = id;
		this.from = from;
		this.to = to;
		this.conversionMultiple = conversionMultiple;
		this.quantity = quantity;
		this.totalCalculatedAmount = totalCalculatedAmount;
		this.port = port;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public BigDecimal getConversionMultiple() {
		return conversionMultiple;
	}

	public void setConversionMultiple(BigDecimal conversionMultiple) {
		this.conversionMultiple = conversionMultiple;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getTotalCalculatedAmount() {
		return totalCalculatedAmount;
	}

	public void setTotalCalculatedAmount(BigDecimal totalCalculatedAmount) {
		this.totalCalculatedAmount = totalCalculatedAmount;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((conversionMultiple == null) ? 0 : conversionMultiple.hashCode());
		result = prime * result + ((from == null) ? 0 : from.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + port;
		result = prime * result + ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result + ((to == null) ? 0 : to.hashCode());
		result = prime * result + ((totalCalculatedAmount == null) ? 0 : totalCalculatedAmount.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CurrencyConversionBean other = (CurrencyConversionBean) obj;
		if (conversionMultiple == null) {
			if (other.conversionMultiple != null)
				return false;
		} else if (!conversionMultiple.equals(other.conversionMultiple))
			return false;
		if (from == null) {
			if (other.from != null)
				return false;
		} else if (!from.equals(other.from))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (port != other.port)
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (to == null) {
			if (other.to != null)
				return false;
		} else if (!to.equals(other.to))
			return false;
		if (totalCalculatedAmount == null) {
			if (other.totalCalculatedAmount != null)
				return false;
		} else if (!totalCalculatedAmount.equals(other.totalCalculatedAmount))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CurrencyConversionBean [id=" + id + ", from=" + from + ", to=" + to + ", conversionMultiple="
				+ conversionMultiple + ", quantity=" + quantity + ", totalCalculatedAmount=" + totalCalculatedAmount
				+ ", port=" + port + "]";
	}

	
}

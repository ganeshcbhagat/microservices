package com.microService.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.microService.entity.User;
import com.microService.repository.UserRepository;
import com.microService.repository.UserRoleMappingRepository;

public class UserDetailServiceImpl implements UserDetailsService {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	//@Autowired
	private UserRepository userRepository;
	
	//@Autowired
	private UserRoleMappingRepository userRoleMappingRepository;
	
	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		Optional<User> userOptional = userRepository.findById(userId);
		if(userOptional.isPresent()) {
			User user= userOptional.get();
			//userRoleMappingRepository.
			return new org.springframework.security.core.userdetails.User(user.getUserId(), user.getPassword(), getAuthority());
		} else {
			RuntimeException exception = new UsernameNotFoundException("Unable to find the User:"+userId);
			LOG.error("Unable to find the User:"+userId, exception);
			throw exception;
		}
	}
	
	private List<GrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
	}

}

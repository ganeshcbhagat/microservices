package com.microService.controller;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microService.entity.User;
import com.microService.repository.UserRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;

@RestController
@Api(value="LoginController giving allowing to login in the application")
public class LoginController {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private UserRepository userRepository;
	
	@PostConstruct
	public void initSomeUser() {
		LOG.info("Inserting some user records in database");
	/*	userRepository.save(new User("USD", "INR", new BigDecimal(65.0),
				Integer.parseInt(environment.getProperty("server.port"))));
		userRepository.save(new User("EUR", "INR", new BigDecimal(75.0),
				Integer.parseInt(environment.getProperty("server.port"))));
		userRepository.save(new User("AUD", "INR", new BigDecimal(25.0),
				Integer.parseInt(environment.getProperty("server.port"))));
		userRepository.flush();*/
	}
	
	@PostMapping("/login")
	@ApiOperation(value = "user Id, password")
	@ApiImplicitParams({@ApiImplicitParam(name = "userId", required = true, dataType = "string", value = "userId"),
						@ApiImplicitParam(name = "password", required = true, dataType = "string", value = "password")})
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = User.class),
	            			@ApiResponse(code = 401, message = "Unauthorized"),
	            			@ApiResponse(code = 403, message = "Forbidden"),
	            			@ApiResponse(code = 404, message = "Not Found"),
	            			@ApiResponse(code = 500, message = "Failure")}) 
	public User loginX(@RequestParam String userId, @RequestParam String password) {
		LOG.info("Retrieve Exchange Value from:"+userId);
		Optional<User> userOptional = userRepository.findById(userId);
		if(userOptional.isPresent()) {
			return userOptional.get();
		} else {
			RuntimeException exception = new RuntimeException("Unable to find the User:"+userId);
			LOG.error("Unable to find the User:"+userId, exception);
			throw exception;
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(){
	     return "login";
	}
}

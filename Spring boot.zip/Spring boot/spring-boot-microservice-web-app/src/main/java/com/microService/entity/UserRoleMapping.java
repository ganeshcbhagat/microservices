package com.microService.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "tbl003_UserRoleMapping")
public class UserRoleMapping {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@ApiModelProperty(notes="user role map Id", required=true)
	private BigDecimal userRoleMapId;
	
	@Column(unique=true)
	@ApiModelProperty(notes="user Id", required=true)
	private String userId;

	@Column(unique=true)
	@ApiModelProperty(notes="role name", required=true)
	private String roleName;

	public UserRoleMapping() {

	}

	public BigDecimal getUserRoleMapId() {
		return userRoleMapId;
	}

	public void setUserRoleMapId(BigDecimal userRoleMapId) {
		this.userRoleMapId = userRoleMapId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserRoleMapping [userRoleMapId=");
		builder.append(userRoleMapId);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", roleName=");
		builder.append(roleName);
		builder.append("]");
		return builder.toString();
	}

	
}
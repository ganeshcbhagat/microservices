package com.microService.application;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan(basePackages = "com.microService")
@EnableJpaRepositories(basePackages = "com.microService.repository")
@EntityScan(basePackages = "com.microService.entity")
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableHystrix
@EnableSwagger2
public class Application {
	
	//http://localhost:8080/api/login
	//http://localhost:8000/api/h2_console
	//http://localhost:8080/api/swagger-ui.html
	//http://localhost:8000/v2/api-docs?group=Spring-Web-App_Group
	// Swagger Online editor
	// https://editor.swagger.io//?_ga=2.113745863.1318765738.1525677110-1434991253.1525677110#/

	// Run on browser as http://localhost:8080/api/hystrix
	// Enter the below url
	// http://localhost:8080/api/hystrix.stream
	// http://localhost:8080/api/turbine.stream?cluster=SPRING-WEB-APP
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	@Bean
	public Docket api() throws IOException, XmlPullParserException {
		return new Docket(DocumentationType.SWAGGER_2).groupName("Spring-Web-App_Group").select()
				.apis(RequestHandlerSelectors.basePackage("com.microService")).paths(PathSelectors.any()).build()
				.apiInfo(apiInfo());
	}

	private ApiInfo apiInfo() throws FileNotFoundException, IOException, XmlPullParserException {
		MavenXpp3Reader reader = new MavenXpp3Reader();
		Model model = reader.read(new FileReader("pom.xml"));
		return new ApiInfoBuilder().title("Spring Web App").description("Spring Web App with Swagger")
				.termsOfServiceUrl("http://localhost:8000/terms")
				.contact(new Contact("Ganesh", "http://localhost:8000/contact", "ganeshcbhagat@gmail.com"))
				.license("My Apache License Version 2.0").licenseUrl("http://localhost:8000/LICENSE")
				.version(model.getParent().getVersion()).build();
	}
	
	/*For Swagger documentation on different server, Need to enable the CORS (Cross-Origin Resource Sharing)*/
	@Bean
	public CorsFilter corsFilter() {
	    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    final CorsConfiguration config = new CorsConfiguration();
	    config.setAllowCredentials(true);
	    config.addAllowedOrigin("*");
	    config.addAllowedHeader("*");
	    config.addAllowedMethod("OPTIONS");
	    config.addAllowedMethod("HEAD");
	    config.addAllowedMethod("GET");
	    config.addAllowedMethod("PUT");
	    config.addAllowedMethod("POST");
	    config.addAllowedMethod("DELETE");
	    config.addAllowedMethod("PATCH");
	    source.registerCorsConfiguration("/**", config);
	    return new CorsFilter(source);
	}
}

package com.microService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microService.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, String>{
  
}
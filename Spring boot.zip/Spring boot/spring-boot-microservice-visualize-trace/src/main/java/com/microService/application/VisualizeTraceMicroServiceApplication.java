package com.microService.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import zipkin.server.internal.EnableZipkinServer;

@SpringBootApplication
@EnableDiscoveryClient
@EnableZipkinServer
public class VisualizeTraceMicroServiceApplication {

	// Run on browser as 
	// http://localhost:9411/zipkin/
	
	public static void main(String[] args) {
		SpringApplication.run(VisualizeTraceMicroServiceApplication.class, args);
	}
	
	
}

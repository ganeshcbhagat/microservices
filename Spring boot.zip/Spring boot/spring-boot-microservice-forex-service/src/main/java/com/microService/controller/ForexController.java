package com.microService.controller;

import java.math.BigDecimal;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.microService.entity.ExchangeValue;
import com.microService.repository.ExchangeValueRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;

@RestController
@Api(value="ForexController giving the exchange rate of currency")
public class ForexController {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private Environment environment;

	@Autowired
	private ExchangeValueRepository repository;

	@PostConstruct
	public void initExchangeValue() {
		LOG.info("Inserting currency exchange record in database");
		repository.save(new ExchangeValue("USD", "INR", new BigDecimal(65.0),
				Integer.parseInt(environment.getProperty("server.port"))));
		repository.save(new ExchangeValue("EUR", "INR", new BigDecimal(75.0),
				Integer.parseInt(environment.getProperty("server.port"))));
		repository.save(new ExchangeValue("AUD", "INR", new BigDecimal(25.0),
				Integer.parseInt(environment.getProperty("server.port"))));
		repository.flush();
	}
	
	@GetMapping("/currency-exchange/from/{from}/to/{to}")
	@HystrixCommand(fallbackMethod = "fallbackMethodIfRetrieveExchangeValueFailed")
	@ApiOperation(value = "from, to")
	@ApiImplicitParams({@ApiImplicitParam(name = "from", defaultValue="USD", required = true, dataType = "string", value = "from value"),
						@ApiImplicitParam(name = "to", defaultValue="INR", required = true, dataType = "string", value = "to value should always INR")})
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ExchangeValue.class),
	            			@ApiResponse(code = 401, message = "Unauthorized"),
	            			@ApiResponse(code = 403, message = "Forbidden"),
	            			@ApiResponse(code = 404, message = "Not Found"),
	            			@ApiResponse(code = 500, message = "Failure")}) 
	public ExchangeValue retrieveExchangeValue(@PathVariable String from, @PathVariable String to) {
		LOG.info("Retrieve Exchange Value from:"+from+" to:"+to);
		ExchangeValue exchangeValue = repository.findByFromAndTo(from, to);
		if(exchangeValue==null) {
			RuntimeException exception = new RuntimeException("Currency exchange not found for "+from+" - "+to);
			LOG.error("Unable to find the currency exchange for from:"+from+" to:"+to, exception);
			throw exception;
		}
		
		return exchangeValue;
	}

	public ExchangeValue fallbackMethodIfRetrieveExchangeValueFailed(@PathVariable String from, @PathVariable String to) {
		LOG.warn("Fallback method for retrieveExchangeValue");
		ExchangeValue exchangeValue = new ExchangeValue(-1L,from, to, new BigDecimal(0), 0);
		return exchangeValue;
	}

}

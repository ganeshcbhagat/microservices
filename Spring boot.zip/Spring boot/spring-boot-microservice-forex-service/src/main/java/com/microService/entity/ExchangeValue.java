package com.microService.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "EXCHANGE_VALUE")
public class ExchangeValue {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@ApiModelProperty(notes="Unique ID", required=true)
	private Long id;

	@Column(name = "currency_from")
	@ApiModelProperty(notes="From currency", required=true)
	private String from;

	@Column(name = "currency_to")
	@ApiModelProperty(notes="To currency", required=true)
	private String to;

	@Column(name = "conversionMultiple")
	@ApiModelProperty(notes="Conversion multipler")
	private BigDecimal conversionMultiple;
	
	@Column(name = "port")
	@ApiModelProperty(notes="Port on which the microservice is running")
	private Integer port;

	public ExchangeValue() {

	}

	public ExchangeValue(String from, String to, BigDecimal conversionMultiple , Integer port) {
		super();
		this.from = from;
		this.to = to;
		this.conversionMultiple = conversionMultiple;
		this.port = port;
	}

	public ExchangeValue(Long id, String from, String to, BigDecimal conversionMultiple, Integer port) {
		super();
		this.id = id;
		this.from = from;
		this.to = to;
		this.conversionMultiple = conversionMultiple;
		this.port = port;
	}

	public Long getId() {
		return id;
	}

	public String getFrom() {
		return from;
	}

	public String getTo() {
		return to;
	}

	public BigDecimal getConversionMultiple() {
		return conversionMultiple;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "ExchangeValue [id=" + id + ", from=" + from + ", to=" + to + ", "+
				"conversionMultiple="+ conversionMultiple + ", port=" + port + "]";
	}

}
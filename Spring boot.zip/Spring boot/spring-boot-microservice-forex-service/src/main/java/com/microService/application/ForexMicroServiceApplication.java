package com.microService.application;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.sleuth.zipkin2.ZipkinProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.DiscoveryClient;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan(basePackages = "com.microService")
@EnableJpaRepositories(basePackages = "com.microService.repository")
@EntityScan(basePackages = "com.microService.entity")
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableHystrix
@EnableSwagger2
public class ForexMicroServiceApplication<SpanMetricReporter> {

	// Run on browser as
	// http://localhost:8000/currency-exchange/from/EUR/to/INR/
	// http://localhost:8000/h2_console
	// http://localhost:8001/currency-exchange/from/EUR/to/INR/
	// http://localhost:8001/h2_console

	// For Swagger UI
	// http://localhost:8000/swagger-ui.html
	// http://localhost:8000/v2/api-docs?group=Forex_Micro_Service_Group
	// Swagger Online editor
	// https://editor.swagger.io//?_ga=2.113745863.1318765738.1525677110-1434991253.1525677110#/

	// Run on browser as http://localhost:8001/hystrix
	// Enter the below url
	// http://localhost:8001/hystrix.stream
	// http://localhost:8001/turbine.stream?cluster=FOREX-SERVICE

	// For different Server port provide -Dserver.port=8001 as VM argument
/*
	@Autowired
	// private EurekaClient eurekaClient;
	private DiscoveryClient eurekaClient;

	@Autowired
	private SpanMetricReporter spanMetricReporter;

	@Autowired
	private ZipkinProperties zipkinProperties;

	@Value("${spring.sleuth.web.skipPattern}")
	private String skipPattern;*/

	public static void main(String[] args) {
		SpringApplication.run(ForexMicroServiceApplication.class, args);
		// TurbineStreamProperties
		// TurbineStreamAutoConfiguration
	}

	/*
	 * @Bean public AlwaysSampler defaultSampler() { return new AlwaysSampler(); }
	 */

/*	@Bean
	public ZipkinSpanReporter makeZipkinSpanReporter() {
		return new ZipkinSpanReporter() {
			private HttpZipkinSpanReporter delegate;
			private String baseUrl;

			@Override
			public void report(Span span) {
				//InstanceInfo instance = eurekaClient.getNextServerFromEureka("visualize-trace-service", false);
				InstanceInfo instance = eurekaClient.getApplications().getRegisteredApplications("visualize-trace-service").getByInstanceId("visualize-trace-service");
				if (!(baseUrl != null && instance.getHomePageUrl().equals(baseUrl))) {
					baseUrl = instance.getHomePageUrl();
					delegate = new HttpZipkinSpanReporter(baseUrl, zipkinProperties.getFlushInterval(),
							zipkinProperties.getCompression().isEnabled(), spanMetricReporter);
					if (!span.name.matches(skipPattern))
						delegate.report(span);
				}
				if (!span.name.matches(skipPattern))
					delegate.report(span);
			}
		};
	}*/

	@Bean
	public Docket api() throws IOException, XmlPullParserException {
		return new Docket(DocumentationType.SWAGGER_2).groupName("Forex_Micro_Service_Group").select()
				.apis(RequestHandlerSelectors.basePackage("com.microService")).paths(PathSelectors.any()).build()
				.apiInfo(apiInfo());
	}

	private ApiInfo apiInfo() throws FileNotFoundException, IOException, XmlPullParserException {
		MavenXpp3Reader reader = new MavenXpp3Reader();
		Model model = reader.read(new FileReader("pom.xml"));
		return new ApiInfoBuilder().title("Forex Micro Service").description("Forex Micro Service with Swagger")
				.termsOfServiceUrl("http://localhost:8000/terms")
				.contact(new Contact("Ganesh", "http://localhost:8000/contact", "ganeshcbhagat@gmail.com"))
				.license("My Apache License Version 2.0").licenseUrl("http://localhost:8000/LICENSE")
				.version(model.getParent().getVersion()).build();
	}
	
	/*For Swagger documentation on different server, Need to enable the CORS (Cross-Origin Resource Sharing)*/
	@Bean
	public CorsFilter corsFilter() {
	    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    final CorsConfiguration config = new CorsConfiguration();
	    config.setAllowCredentials(true);
	    config.addAllowedOrigin("*");
	    config.addAllowedHeader("*");
	    config.addAllowedMethod("OPTIONS");
	    config.addAllowedMethod("HEAD");
	    config.addAllowedMethod("GET");
	    config.addAllowedMethod("PUT");
	    config.addAllowedMethod("POST");
	    config.addAllowedMethod("DELETE");
	    config.addAllowedMethod("PATCH");
	    source.registerCorsConfiguration("/**", config);
	    return new CorsFilter(source);
	}
}

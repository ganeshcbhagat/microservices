package com.spring.aop;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
//@EnableAspectJAutoProxy Enabled in configuration class
public class AspectClass {

	@Before(value = "execution(* com.spring.aop.BusinessClass.*(..))")
	public void methodBefore(JoinPoint joinPoint) {
		System.out.println("methodBefore: "+joinPoint);
	}
	
	@After(value = "execution(* com.spring.aop.BusinessClass.*(..))")
	public void methodAfter( JoinPoint joinPoint) {
		System.out.println("methodAfter: "+joinPoint);
	}
	
	@Around(value = "execution(* com.spring.aop.BusinessClass.*(..))")
	public Object methodAround(ProceedingJoinPoint proceedingJoinPoint) {
		Object proceed = null;
		System.out.println("methodAround: ----- "+proceedingJoinPoint);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			proceed = proceedingJoinPoint.proceed();
			if(proceed instanceof String) {
				String tempString = (String)proceed;
				tempString = "Modifyed returned message: "+tempString;
				proceed = tempString;
			}
		} catch (Throwable e) {
			//e.printStackTrace();
		}
		stopWatch.stop();
		System.out.println("methodAround: ----- total time taken (ms) : "+stopWatch.getTotalTimeMillis());
		
		return proceed;
	}
	
	/*@Around(value="com.spring.aop.PointCutClass.methodTrackExecutionTime()")
	public void methodTrackExecutionTime(ProceedingJoinPoint proceedingJoinPoint) {
		System.out.println("methodTrackExecutionTime: ----- "+proceedingJoinPoint);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			proceedingJoinPoint.proceed();
		} catch (Throwable e) {
			//e.printStackTrace();
		}
		stopWatch.stop();
		System.out.println("methodtrackExecutionTime: ----- total time taken (ms) : "+stopWatch.getTotalTimeMillis());
	}*/
	
	@AfterReturning(value = "execution(* com.spring.aop.BusinessClass.*(..))")
	public void methodAfterReturning(JoinPoint joinPoint) {
		System.out.println("methodAfterReturning: "+joinPoint);
	}
	
	@AfterReturning(pointcut="com.spring.aop.PointCutClass.methodForArgumentStringAndFloat(msg, value)", returning="result")
	public void methodForArgumentAndAfterReturning(JoinPoint joinPoint, String msg, float value, List<String> result) {
		System.out.println("methodForArgumentAndAfterReturning: "+joinPoint+ " argument values are msg:"+msg+", value:"+value + ", returning:"+result);
	}
	
	@AfterThrowing(pointcut = "execution(* com.spring.aop.BusinessClass.*(..))", throwing="runtimeException")
	public void methodAfterThrowing(JoinPoint joinPoint, RuntimeException runtimeException) {
		System.out.println("methodAfterThrowing: "+joinPoint+" runtimeException="+runtimeException.getMessage());
	}
	
}

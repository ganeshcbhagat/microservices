package com.spring.propertyFileMapping;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "outlook", ignoreUnknownFields=false, ignoreInvalidFields=false)
@PropertySource("classpath:OutlookProperty.properties")

/*For multiple Properties to single class*/
/*@PropertySources({
	@PropertySource("classpath:config.properties"),
	@PropertySource("classpath:db.properties")
})*/
public class OutlookProperty {

	private String smtpServerName;
	private int port;
	private String emailBox;
	
	private PluginProperty pluginProperty;
	
	public OutlookProperty() {

	}

	public OutlookProperty(String smtpServerName, int port, String emailBox, PluginProperty pluginProperty) {
		super();
		this.smtpServerName = smtpServerName;
		this.port = port;
		this.emailBox = emailBox;
		this.pluginProperty = pluginProperty;
	}

	public String getSmtpServerName() {
		return smtpServerName;
	}

	public void setSmptServerName(String smtpServerName) {
		this.smtpServerName = smtpServerName;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getEmailBox() {
		return emailBox;
	}

	public void setEmailBox(String emailBox) {
		this.emailBox = emailBox;
	}

	public PluginProperty getPluginProperty() {
		return pluginProperty;
	}

	public void setPluginProperty(PluginProperty pluginProperty) {
		this.pluginProperty = pluginProperty;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OutlookProperty [smtpServerName=");
		builder.append(smtpServerName);
		builder.append(", port=");
		builder.append(port);
		builder.append(", emailBox=");
		builder.append(emailBox);
		builder.append(", pluginProperty=");
		builder.append(pluginProperty);
		builder.append("]");
		return builder.toString();
	}
	
}

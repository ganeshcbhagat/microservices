package com.spring.propertyFileMapping;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:AnotherProperty.properties")
public class AnotherProperty {

	@Value("${name}")
	private String name;
	
	@Value("${randomPort}")
	private int randomPort;
	
	@Value("${description}")
	private String description;
	
	public AnotherProperty() {

	}

	public AnotherProperty(String name, int randomPort, String description) {
		this.name = name;
		this.randomPort=randomPort;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRandomPort() {
		return randomPort;
	}

	public void setRandomPort(int randomPort) {
		this.randomPort = randomPort;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AnotherProperty [name=");
		builder.append(name);
		builder.append(", randomPort=");
		builder.append(randomPort);
		builder.append(", description=");
		builder.append(description);
		builder.append("]");
		return builder.toString();
	}
	
}

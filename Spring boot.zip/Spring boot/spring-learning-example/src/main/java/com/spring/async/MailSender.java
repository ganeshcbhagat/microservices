package com.spring.async;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import java.util.concurrent.Future;

@Component
public class MailSender {

    public void nonAsyncMethod() throws InterruptedException {
        System.out.println("connecting to server......"+ Thread.currentThread());
        Thread.sleep(100);
        System.out.println("connected to server done "+ Thread.currentThread());
    }
	
    @Async
    public String runAsyncTask (String message) {
        System.out.println("Message:"+message +" Running task thread "+Thread.currentThread());
        return "return value";
    }
    
    @Async
    public Future<Boolean> sendMail() throws InterruptedException {
        System.out.println("sending mail.."+ Thread.currentThread());
        Thread.sleep(100);
        System.out.println("sending mail completed "+ Thread.currentThread());
        return new AsyncResult<Boolean>(true);
    }
    
    @Async("threadPoolTaskExecutor")
    public void asyncMethodWithConfiguredExecutor() {
        System.out.println("Execute method with configured executor - "+ Thread.currentThread());
    }
    
    @Async
    public void asyncMethodWithException(String parameter) {
        System.out.println("Execute asyncMethodWithException method to throw an exception "+ Thread.currentThread());
        throw new RuntimeException("Throwing test runtime exception");
    }
}

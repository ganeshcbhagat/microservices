package com.spring.bean;

import org.springframework.beans.factory.annotation.Autowired;
import javax.inject.Provider;
import org.springframework.stereotype.Component;

@Component
public class SingletonBean_5 {
	
	/*
	 * Add below dependency to use import javax.inject.Provider;
	 * <dependency>
	    <groupId>javax.inject</groupId>
	    <artifactId>javax.inject</artifactId>
	    <version>1</version>
    </dependency>*/

	@Autowired
    private Provider<PrototypeBean> prototypeBeanProvider;
	
	public void showMessage() {
		System.out.println("SingletonBean_5: " + prototypeBeanProvider.get().getDateTime());
	}

}

package com.spring.propertyFileMapping;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.concurrent.ExecutionException;

public class PropertyFileMappingExampleApplication {

	public static void main(String... args) throws InterruptedException, ExecutionException {

		System.out.println("Main Program Thread start :" + Thread.currentThread());
		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		OutlookProperty outlookPropertyObj = context.getBean(OutlookProperty.class);
		System.out.println("outlookPropertyObj="+outlookPropertyObj);
		
		AnotherProperty anotherPropertyObj = context.getBean(AnotherProperty.class);
		System.out.println("anotherPropertyObj="+anotherPropertyObj);
		
		DatabaseProperty databasePropertyObj = context.getBean(DatabaseProperty.class);
		System.out.println("databasePropertyObj="+databasePropertyObj);
		
		SpringConfig springConfigObj = context.getBean(SpringConfig.class);
		System.out.println("Loggin Config Map="+springConfigObj.myProperties);
		
        System.out.println("Main Program Thread Exit :" + Thread.currentThread());
	}

}

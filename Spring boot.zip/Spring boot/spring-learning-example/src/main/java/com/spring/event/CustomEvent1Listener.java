package com.spring.event;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class CustomEvent1Listener implements ApplicationListener<CustomEvent1>{

	public void onApplicationEvent(CustomEvent1 event) {
		 System.out.println("Received spring custom event - " + event.getMessage());		
	}

}

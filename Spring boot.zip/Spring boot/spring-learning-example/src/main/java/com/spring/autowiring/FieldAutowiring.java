package com.spring.autowiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FieldAutowiring {
	
	@Autowired
	private DependencyX dependencyX;

	public FieldAutowiring() {
		System.out.println("Constructor of FieldAutowiring");
	}
	
	public void showMessage() {
		System.out.println("In FieldAutowiring");
		dependencyX.showMessage();
	}
}

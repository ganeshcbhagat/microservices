package com.spring.bean;

import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

@Component
public class SingletonBean_3 {
	
	/*The bean class cannot be final.
	The method annotated with @Lookup, cannot be private , static or final
	Use @Component
	The factory approach of JavaConfig doesn't work i.e. a factory method 
	annotated with @Bean and returning a manually created instance of the bean doesn't work. 
	Since the container is not in charge of creating the instance, therefore it cannot create a 
	runtime-generated subclass on the fly. So we have to use component scanning approach */
	@Lookup
	public PrototypeBean getPrototypeBean() {
		//Spring is overriding this method dynamically
		return null;	
	}

	public void showMessage() {
		System.out.println("SingletonBean_3: " + getPrototypeBean().getDateTime());
	}

}

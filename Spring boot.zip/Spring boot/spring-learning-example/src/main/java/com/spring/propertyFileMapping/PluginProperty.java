package com.spring.propertyFileMapping;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(ignoreUnknownFields=true, ignoreInvalidFields=false)
public class PluginProperty {

	private String pluginName;
	private String libList[];
	private List<String> installationDir;
	private Map<String,String> keyLocationMap;
	
	public PluginProperty() {

	}
	
	public PluginProperty(String pluginName, String[] libList, List<String> installationDir, Map<String,String> keyLocationMap) {
		super();
		this.pluginName = pluginName;
		this.libList = libList;
		this.installationDir = installationDir;
		this.keyLocationMap=keyLocationMap;
	}

	public String getPluginName() {
		return pluginName;
	}

	public void setPluginName(String pluginName) {
		this.pluginName = pluginName;
	}

	public String[] getLibList() {
		return libList;
	}

	public void setLibList(String[] libList) {
		this.libList = libList;
	}

	public List<String> getInstallationDir() {
		return installationDir;
	}

	public void setInstallationDir(List<String> installationDir) {
		this.installationDir = installationDir;
	}

	public Map<String, String> getKeyLocationMap() {
		return keyLocationMap;
	}

	public void setKeyLocationMap(Map<String, String> keyLocationMap) {
		this.keyLocationMap = keyLocationMap;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PluginProperty [pluginName=");
		builder.append(pluginName);
		builder.append(", libList=");
		builder.append(Arrays.toString(libList));
		builder.append(", installationDir=");
		builder.append(installationDir);
		builder.append(", keyLocationMap=");
		builder.append(keyLocationMap);
		builder.append("]");
		return builder.toString();
	}
	
}

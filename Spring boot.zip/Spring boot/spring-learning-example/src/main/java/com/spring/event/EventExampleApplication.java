package com.spring.event;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.concurrent.ExecutionException;

public class EventExampleApplication {

	public static void main(String... args) throws InterruptedException, ExecutionException {

		System.out.println("Main Program Thread start :" + Thread.currentThread());
		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		CustomEvent1Publisher customEvent1Publisher = context.getBean(CustomEvent1Publisher.class);
		customEvent1Publisher.doStuffAndPublishAnEvent("Hello This is my message");
        System.out.println("Main Program Thread Exit :" + Thread.currentThread());
	}

}

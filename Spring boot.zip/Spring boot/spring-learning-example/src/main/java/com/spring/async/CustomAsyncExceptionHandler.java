package com.spring.async;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Component
public class CustomAsyncExceptionHandler implements AsyncUncaughtExceptionHandler {
 
	public void handleUncaughtException(Throwable throwable, Method method, Object... obj) {
  
        System.out.println("Method name [" + method.getName()+ "] Exception message - " + throwable.getMessage());
        for (Object param : obj) {
            System.out.println("Parameter value - " + param);
        }
    }
}

package com.spring.propertyFileMapping;

/*Consider that you can not modify this class. It is given by some library but you want to set its property
 * Then create its bean in spring configuration and apply @ConfigurationProperties there check SpringConfig.java
 * */ 
public class DatabaseProperty {
	private String url;
	private int port;
	private String user;
	private String password;
	
	public DatabaseProperty() {

	}

	public DatabaseProperty(String url, int port, String user, String password) {
		super();
		this.url = url;
		this.port = port;
		this.user = user;
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DatabaseProperty [url=");
		builder.append(url);
		builder.append(", port=");
		builder.append(port);
		builder.append(", user=");
		builder.append(user);
		builder.append(", password=");
		builder.append(password);
		builder.append("]");
		return builder.toString();
	}
	
}

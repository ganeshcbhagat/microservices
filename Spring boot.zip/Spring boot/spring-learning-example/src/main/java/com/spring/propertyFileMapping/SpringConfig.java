package com.spring.propertyFileMapping;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;

@Configuration
@EnableConfigurationProperties
@ComponentScan("com.spring.propertyFileMapping")
@PropertySource("classpath:Database.properties")
public class SpringConfig {

	/* DatabaseProperty class is given by third party API so here we are creating its bean. 
	 * its properties are set in Database.properties file 
	 * so @PropertySource("classpath:Database.properties") is given here
	 * */
	@Bean
	@ConfigurationProperties(prefix = "db")
	public DatabaseProperty getDatabaseProperty() {
		return new DatabaseProperty();
	}
	
	//myloggingProperties Bean is injected here
	@Resource(name = "myloggingProperties")
	public Map<String, String> myProperties;
	
	//Check myProperties map injected as @Resource(name = "myloggingProperties")
	@Bean(name = "myloggingProperties")
	public static PropertiesFactoryBean propertyMapper() {
	    PropertiesFactoryBean bean = new PropertiesFactoryBean();
	    bean.setLocation(new ClassPathResource("Logging.properties"));
	    return bean;
	}
}

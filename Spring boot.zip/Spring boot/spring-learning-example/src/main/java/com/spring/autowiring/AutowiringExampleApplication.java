package com.spring.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.concurrent.ExecutionException;

public class AutowiringExampleApplication {

	public static void main(String... args) throws InterruptedException, ExecutionException {

		System.out.println("Main Program Thread start :" + Thread.currentThread());
		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		FieldAutowiring fieldAutowiring = context.getBean(FieldAutowiring.class);
		fieldAutowiring.showMessage();
		
		System.out.println("--------------------------------------------");
		

		ConstructorAutowiring constructorAutowiring = context.getBean(ConstructorAutowiring.class);
		constructorAutowiring.showMessage();
		
		System.out.println("--------------------------------------------");
		
		SetterAutowiring setterAutowiring = context.getBean(SetterAutowiring.class);
		setterAutowiring.showMessage();
		
		System.out.println("--------------------------------------------");
        System.out.println("Main Program Thread Exit :" + Thread.currentThread());
	}

}

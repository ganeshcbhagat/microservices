package com.spring.aop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class BusinessClass {

	public void simpleMethod() {
		System.out.println("BusinessClass : executing simpleMethod");
	}
	
	public List<String> simpleMethodWithArgument(String msg, float value) {
		List<String> result = new ArrayList<String>();
		result.add("1");
		result.add("2");
		result.add("3");
		result.add("4");
		System.out.println("BusinessClass : executing simpleMethodWithArgument msg="+msg+", value="+value + " returning="+result);
		return result;
	}
	
	public String methodReturingValue() {
		String str = "Returing some value "+ Math.random();
		System.out.println("BusinessClass : executing methodReturingValue : "+str);
		return str;
	}
	
	public void methodThrowingAnException() {
		System.out.println("BusinessClass : executing methodThrowingAnException");
		throw new RuntimeException("Throwing an exception from methodThrowingAnException()");
	}
	
	@TrackExecutionTime
	public void methodUnderTimeExecutionMonitoring() {
		System.out.println("BusinessClass : executing methodUnderTimeExecutionMonitoring");
		try {
			Thread.sleep((long) (Math.random()*1000));
		} catch (InterruptedException e) { e.printStackTrace(); }
	}
	
}

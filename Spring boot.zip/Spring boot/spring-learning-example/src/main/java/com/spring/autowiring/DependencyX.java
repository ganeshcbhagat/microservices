package com.spring.autowiring;

import org.springframework.stereotype.Component;

public class DependencyX {

	public DependencyX() {
		System.out.println("Constructor of DependencyX");
	}
	
	public void showMessage() {
		System.out.println("In DependencyX");
	}
	
}

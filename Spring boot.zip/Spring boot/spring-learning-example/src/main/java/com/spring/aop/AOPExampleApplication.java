package com.spring.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.concurrent.ExecutionException;

public class AOPExampleApplication {

	public static void main(String... args) throws InterruptedException, ExecutionException {

		System.out.println("Main Program Thread start :" + Thread.currentThread());
		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigAspect.class);
		
		BusinessClass businessClassObj = context.getBean(BusinessClass.class);
	/*	System.out.println("----------------------------------------");
		businessClassObj.simpleMethod();
		System.out.println("----------------------------------------");
		businessClassObj.simpleMethodWithArgument("Hello Msg",123.0F);*/
		System.out.println("----------------------------------------");
		System.out.println(businessClassObj.methodReturingValue());
		System.out.println("----------------------------------------");
		businessClassObj.methodUnderTimeExecutionMonitoring();
		/*System.out.println("----------------------------------------");
		businessClassObj.methodThrowingAnException();
		System.out.println("----------------------------------------");*/
		
        System.out.println("Main Program Thread Exit :" + Thread.currentThread());
	}

}

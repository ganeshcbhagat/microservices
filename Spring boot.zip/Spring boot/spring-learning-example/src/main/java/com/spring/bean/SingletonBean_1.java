package com.spring.bean;

import org.springframework.beans.factory.annotation.Autowired;

public class SingletonBean_1 {
	
	@Autowired
	private PrototypeBean prototypeBean;

	public void showMessage() {
		System.out.println("SingletonBean_1: " + prototypeBean.getDateTime());
	}
}

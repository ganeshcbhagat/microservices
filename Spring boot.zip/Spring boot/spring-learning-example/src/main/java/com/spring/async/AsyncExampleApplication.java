package com.spring.async;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;

public class AsyncExampleApplication {

	public static void main(String... args) throws InterruptedException, ExecutionException {

		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringAsyncConfig.class);
		MailSender mailSender = context.getBean(MailSender.class);

		System.out.println("Main Program Thread start :" + Thread.currentThread());

		mailSender.nonAsyncMethod();
		
		String returnValue = mailSender.runAsyncTask("Hello test message");
		
		Future<Boolean> future = mailSender.sendMail();
		System.out.println("this will run immediately. " + Thread.currentThread());
		Boolean result = future.get();
		
		System.out.println("mail send result: " + result + " " + Thread.currentThread());
		
		System.out.println("Returning something: "+returnValue);
		
		mailSender.asyncMethodWithConfiguredExecutor();
		
		mailSender.asyncMethodWithException("testParameter");
		
		ThreadPoolTaskExecutor exec = context.getBean(ThreadPoolTaskExecutor.class);
        exec.getThreadPoolExecutor().shutdown();
        
        System.out.println("Main Program Thread Exit :" + Thread.currentThread());
	}

}

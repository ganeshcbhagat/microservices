package com.spring.autowiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ConstructorAutowiring {
	
	private DependencyX dependencyX;

	@Autowired
	public ConstructorAutowiring(DependencyX dependencyX) {
		System.out.println("Constructor of ConstructorAutowiring");
		this.dependencyX= dependencyX;
	}
	
	public void showMessage() {
		System.out.println("In ConstructorAutowiring");
		dependencyX.showMessage();
	}
}

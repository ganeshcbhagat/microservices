package com.spring.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SingletonBean_4 {
	
	@Autowired
	public PrototypeBean prototypeBean;

	public void showMessage() {
		System.out.println("SingletonBean_4: " + prototypeBean.getDateTime());
	}

}

package com.spring.event;

import org.springframework.context.ApplicationEvent;
import org.springframework.stereotype.Component;

@Component
public class CustomEvent1 extends ApplicationEvent {

	private static final long serialVersionUID = -3306831657771116089L;
	private String message;
	
	//public Event1(Object source, String message) {
	public CustomEvent1(Object source) {
		super(source);
	}

	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
}

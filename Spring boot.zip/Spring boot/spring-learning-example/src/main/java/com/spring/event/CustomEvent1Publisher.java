package com.spring.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class CustomEvent1Publisher {

	@Autowired
	private ApplicationEventPublisher applicationEventPublisher;

	public void doStuffAndPublishAnEvent(final String message) {
		System.out.println("Publishing custom event. ");
		CustomEvent1 event = new CustomEvent1(this);
		event.setMessage(message);
		applicationEventPublisher.publishEvent(event);
	}

}

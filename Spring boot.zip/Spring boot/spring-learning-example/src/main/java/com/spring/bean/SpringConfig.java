package com.spring.bean;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

@Configuration
@ComponentScan("com.spring.bean")
public class SpringConfig{
 
	@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
	public SingletonBean_1 singletonBean_1() {
		return new SingletonBean_1();
	}
	
	@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
	public SingletonBean_2 singletonBean_2() {
		return new SingletonBean_2();
	}
	
	/*Don't create bean here @Component is Used in class otherwise it will not work
	  Scanning approach is used here*/
	/*@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
	public SingletonBean_3 singletonBean_3() {
		return new SingletonBean_3();
	}*/
	
	 @Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
	 public SingletonBean_5 singletonBean_5() {
			return new SingletonBean_5();
	 }
	 
	@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	//@Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.TARGET_CLASS) // For singletonBean_4 
	public PrototypeBean prototypeBean() {
		return new PrototypeBean();
	}

}

package com.spring.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class SingletonBean_2 {

	@Autowired
    private ApplicationContext applicationContext;

	public void showMessage() {
		PrototypeBean prototypeBean = applicationContext.getBean(PrototypeBean.class);
		System.out.println("SingletonBean_2: " + prototypeBean.getDateTime());
	}
}

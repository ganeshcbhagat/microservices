package com.spring.autowiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SetterAutowiring {
	
	private DependencyX dependencyX;

	public SetterAutowiring() {
		System.out.println("Constructor of SetterAutowiring");
	}
	
	public void showMessage() {
		System.out.println("In SetterAutowiring");
		dependencyX.showMessage();
	}
	
	@Autowired
	public void setDependencyX(DependencyX dependencyX) {
		System.out.println("Setter of SetterAutowiring");
		this.dependencyX = dependencyX;
	}
}

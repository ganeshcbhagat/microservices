package com.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.concurrent.ExecutionException;

public class BeanExampleApplication {

	public static void main(String... args) throws InterruptedException, ExecutionException {

		System.out.println("Main Program Thread start :" + Thread.currentThread());
		@SuppressWarnings("resource")
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		SingletonBean_1 singletonBean_1 = context.getBean(SingletonBean_1.class);
		singletonBean_1.showMessage();
		Thread.sleep(1000);
		SingletonBean_1 singletonBean_1x = context.getBean(SingletonBean_1.class);
		singletonBean_1x.showMessage();
		
		System.out.println("--------------------------------------------");
		
		SingletonBean_2 singletonBean_2 = context.getBean(SingletonBean_2.class);
		singletonBean_2.showMessage();
		Thread.sleep(1000);
		SingletonBean_2 singletonBean_2x = context.getBean(SingletonBean_2.class);
		singletonBean_2x.showMessage();
		
		System.out.println("--------------------------------------------");
		
		SingletonBean_3 singletonBean_3 = context.getBean(SingletonBean_3.class);
		singletonBean_3.showMessage();
		Thread.sleep(1000);
		SingletonBean_3 singletonBean_3x = context.getBean(SingletonBean_3.class);
		singletonBean_3x.showMessage();
		
		System.out.println("--------------------------------------------");
		
		/*Change the scope of PrototypeBean as follows
		@Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.TARGET_CLASS) // For singletonBean_4
		If Prototype class implemented some interface then you can use as below
		@Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.INTERFACES) // For singletonBean_4
		*/
		SingletonBean_4 singletonBean_4 = context.getBean(SingletonBean_4.class);
		singletonBean_4.showMessage();
		Thread.sleep(1000);
		SingletonBean_4 singletonBean_4x = context.getBean(SingletonBean_4.class);
		singletonBean_4x.showMessage();
		
		System.out.println("--------------------------------------------");
		
		SingletonBean_5 singletonBean_5 = context.getBean(SingletonBean_5.class);
		singletonBean_5.showMessage();
		Thread.sleep(1000);
		SingletonBean_5 singletonBean_5x = context.getBean(SingletonBean_5.class);
		singletonBean_5x.showMessage();
		
		System.out.println("--------------------------------------------");
        System.out.println("Main Program Thread Exit :" + Thread.currentThread());
	}

}

package com.microService.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.ComponentScan;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan(basePackages = "com.microService")
@EnableDiscoveryClient
//@EnableZuulProxy
@EnableSwagger2
public class DocumentationMicroServiceApplication {

	// Run on browser as For Swagger UI
	// http://localhost:8900/swagger-ui.html
	// Swagger Online editor https://editor.swagger.io//?_ga=2.113745863.1318765738.1525677110-1434991253.1525677110#/
	
	public static void main(String[] args) {
		SpringApplication.run(DocumentationMicroServiceApplication.class, args);
	}

}
